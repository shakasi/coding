﻿namespace UnitOfWork
{
    public interface IApplicationService
    {
        
    }
}