﻿namespace UnitOfWork
{
    public interface IUnitOfWork
    {
        int SaveChanges();
    }
}
